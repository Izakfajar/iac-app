<x-layout>

    <x-slot:title>Home page</x-slot:title>

    @livewire('projects')

</x-layout>
