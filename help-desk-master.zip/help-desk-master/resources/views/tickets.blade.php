<x-layout>

    <x-slot:title>Tickets</x-slot:title>

    @livewire('tickets')

</x-layout>
