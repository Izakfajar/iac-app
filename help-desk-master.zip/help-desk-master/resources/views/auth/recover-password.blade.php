<x-guest-layout>

    <x-slot:title>Recover password</x-slot:title>

    @livewire('auth.recover-password', ['token' => $token])

</x-guest-layout>
