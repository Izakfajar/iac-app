<x-guest-layout>

    <x-slot:title>Forgot password</x-slot:title>

    @livewire('auth.activate-account', ['user' => $user])

</x-guest-layout>
