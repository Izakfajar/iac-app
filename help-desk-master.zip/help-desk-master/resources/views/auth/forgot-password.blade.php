<x-guest-layout>

    <x-slot:title>Forgot password</x-slot:title>

    @livewire('auth.forgot-password')

</x-guest-layout>
