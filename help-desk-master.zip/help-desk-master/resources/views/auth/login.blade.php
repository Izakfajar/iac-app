<x-guest-layout>

    <x-slot:title>Authentication</x-slot:title>

    @livewire('auth.login')

</x-guest-layout>
