<x-layout>

    <x-slot:title>Analytics</x-slot:title>

    @livewire('analytics')

</x-layout>
