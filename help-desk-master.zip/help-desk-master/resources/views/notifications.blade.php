<x-layout>

    <x-slot:title>Notifications</x-slot:title>

    @livewire('my-notifications')

</x-layout>
