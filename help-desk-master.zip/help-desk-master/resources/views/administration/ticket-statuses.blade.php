<x-layout>

    <x-slot:title>Administration - Tickets statuses</x-slot:title>

    @livewire('administration.ticket-statuses')

</x-layout>
