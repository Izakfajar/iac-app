<x-layout>

    <x-slot:title>Administration - Companies</x-slot:title>

    @livewire('administration.companies')

</x-layout>
