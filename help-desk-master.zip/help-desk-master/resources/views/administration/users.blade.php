<x-layout>

    <x-slot:title>Administration - Users</x-slot:title>

    @livewire('administration.users')

</x-layout>
