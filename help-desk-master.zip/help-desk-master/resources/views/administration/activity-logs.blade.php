<x-layout>

    <x-slot:title>Administration - Activity logs</x-slot:title>

    @livewire('administration.activity-logs')

</x-layout>
