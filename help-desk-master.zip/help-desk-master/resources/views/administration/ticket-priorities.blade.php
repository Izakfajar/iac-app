<x-layout>

    <x-slot:title>Administration - Tickets priorities</x-slot:title>

    @livewire('administration.ticket-priorities')

</x-layout>
