<x-layout>

    <x-slot:title>Administration - Roles</x-slot:title>

    @livewire('administration.roles')

</x-layout>
