<x-layout>

    <x-slot:title>Administration - Tickets types</x-slot:title>

    @livewire('administration.ticket-types')

</x-layout>
